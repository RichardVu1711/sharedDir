#pragma once
#include "../lib/mat_lib.h"
#include "../lib/global_define.h"
#include "../lib/GISmsmt_prcs.h"

void GISobs_model(Mat_S* prtcl_X, int step, msmt* msmtinfo, Mat_S* z_cap);


