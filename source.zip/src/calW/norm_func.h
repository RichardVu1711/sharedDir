//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: norm_func.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Jan-2022 13:02:19
//

#ifndef NORM_FUNC_H
#define NORM_FUNC_H

// Include Files
#include "../lib/mat_lib.h"
#include "../lib/global_define.h"

// Function Declarations
void norm_func(fixed_type X[2],fixed_type* norm_error);

#endif
//
// File trailer for norm_func.h
//
// [EOF]
//
